package collections;

import java.util.concurrent.PriorityBlockingQueue;

public class Priorityqueue {
public static void main(String args[])
{
	PriorityBlockingQueue<Integer> pque=new PriorityBlockingQueue<Integer>(2);
	pque.add(10);
	pque.add(20);
	pque.add(30);
	pque.add(40);
	
}
}
