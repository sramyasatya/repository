package exception;

public class Calc {
	div()
	{
		
	}
}
