package exception;

public class MyOwnException extends Exception{
	public MyOwnException(String s) {
	super();
	}
}
