package exception;

public class Exception {
public Exception()
{
	super();
}
}
