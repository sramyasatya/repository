          package instantandstatic;
import java.util.*;
public class Instantandstaticmethods {
static String defaultval;
static private String privateVar;
static public String publicVar;
static protected String protectedVar;
int x=10;
int y=10;
public static void main(String args[])
{ 
	System.out.println(privateVar);

Instantandstaticmethods a=new Instantandstaticmethods();
System.out.println(a.x);
	//Scanner sc=new Scanner(System.in);
	//int num;
	//num=sc.nextInt();
	//for(int i=0;i<num;i++)
	//{
	// a[i]=sc.nextInt();
	//}
	//public int sum()
	//{
	//	
	//}
	
}
public void sum()
{System.out.println();
	//int a;
}
}
