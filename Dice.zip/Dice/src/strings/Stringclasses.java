package strings;

public class Stringclasses {
public static void main(String args[])
{
	String str1=new String();
	String str2=new String();
	
}
}
