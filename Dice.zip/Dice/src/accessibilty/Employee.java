package accessibilty;

public class Employee {
	
	private int id;
	

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}

	
	

	public Employee(int id) {
		super();
		this.id = id;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e1 = new Employee();
		e1
	}

}
