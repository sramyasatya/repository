package accessibilty;

public class Parent {
void m1()
{
}
void m2()
{
}
//instance methods so create objects in child
}

