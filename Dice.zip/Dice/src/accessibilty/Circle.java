package accessibilty;

public class Circle implements Shape {
@Override
public void draw()
{
	System.out.println("circle");
}
@Override
public void getArea()
{
	System.out.println("Area");
}
}
