package accessibilty;

public class Cohesion {

}
