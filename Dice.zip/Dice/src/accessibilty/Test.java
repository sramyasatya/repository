package accessibilty;

public class Test {
	public static void main(String args[])
	{
		Shape c=new Circle();
		c.draw();
		c.getArea();

	Shape r=new Rectangle();
	r.draw();
	r.getArea();
	
	}
}
