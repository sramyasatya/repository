package inheritance;

public class Inheritancemainprog {

}
